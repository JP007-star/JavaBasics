import java.util.Scanner;

public class DataTypes {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a integer");
        int integer= sc.nextInt();
        System.out.println(integer);
        System.out.println("Enter a character");
        String character= sc.next();
        System.out.println(character);
        System.out.println("Enter a float");
        float decimal= sc.nextFloat();
        System.out.println(decimal);
    }
}
