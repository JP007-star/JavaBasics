public class LaptopDemo {
    public static void main(String[] args) {
        Laptop l1=new Laptop();
        l1.initialize(4,40,"intel",8.14);
        l1.display();
    }
}
