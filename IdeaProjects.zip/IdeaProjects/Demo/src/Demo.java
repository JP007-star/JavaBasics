public class Demo{
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            System.out.println("jaya prasad.m");
        }
    }
}