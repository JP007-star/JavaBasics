package com.torryharris.model;

public interface Aeroplane extends Vehicle {
    void fly();
}
