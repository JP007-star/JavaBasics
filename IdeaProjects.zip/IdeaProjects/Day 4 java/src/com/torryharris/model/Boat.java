package com.torryharris.model;

public interface Boat extends Vehicle{
    void floating();
}
