package com.torryharris.model;

public interface Mammal {
    void feed();
    void eat();
}
