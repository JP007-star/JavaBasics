package com.torryharris.model;

public interface Bird extends Animal {
    void fly();
    void eat();
}
