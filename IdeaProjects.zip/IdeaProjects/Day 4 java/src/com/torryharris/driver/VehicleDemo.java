package com.torryharris.driver;


import com.torryharris.model.Car;
import com.torryharris.model.Swift;

public class VehicleDemo {
    public static void main(String[] args) {
       Car swift=new Swift();
       swift.changeGear();
    }
}
