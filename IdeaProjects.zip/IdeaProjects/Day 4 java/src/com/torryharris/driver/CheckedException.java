package com.torryharris.driver;

public class CheckedException {

}
