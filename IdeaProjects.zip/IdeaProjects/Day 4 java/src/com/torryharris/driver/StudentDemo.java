package com.torryharris.driver;

import com.torryharris.model.Student;

public class StudentDemo {
    public static void main(String[] args) {
        Student jp=new Student("Scad CET",9528,"TIRUNELVELI","EEE",105,"JP",013);
        System.out.println(jp.toString());
    }
}
